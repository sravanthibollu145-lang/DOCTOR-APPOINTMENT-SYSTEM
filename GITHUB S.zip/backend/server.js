const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

const doctors = [
  {id:1, name:"Dr. Ravi Kumar", specialist:"Cardiologist", fee:500},
  {id:2, name:"Dr. Priya Sharma", specialist:"Dentist", fee:300},
  {id:3, name:"Dr. Arjun", specialist:"General", fee:200}
];

let appointments = [];

app.get('/api/doctors', (req,res)=>{
  res.json(doctors);
});

app.post('/api/appointments', (req,res)=>{
  appointments.push(req.body);
  console.log("New:", req.body);
  res.json({message:"Saved"});
});

app.get('/api/appointments', (req,res)=>{
  res.json(appointments);
});

app.listen(5000, ()=> console.log("Backend running on 5000"));